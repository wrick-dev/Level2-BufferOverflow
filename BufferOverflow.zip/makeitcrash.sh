#!/bin/bash
 
g++ -fno-stack-protector question.cpp -o vulnerable -z execstack -D_FORTIFY_SOURCE=0
ulimit -c unlimited
./vulnerable <<'EOF'
5000
99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999
EOF
